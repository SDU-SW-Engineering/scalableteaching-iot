# Test implementation

This directory contains a set of ESP-IDF projects to be used as tests only, which aim to exercise various
configuration of components to check completely arbitrary functionality should it be building only, executing under
various conditions or combination with other components, including custom test frameworks.

The tests in this folder are not intended to demonstrate the ESP-IDF functionality in any way.

The examples can be found here: https://github.com/espressif/esp-idf/tree/master/examples/protocols/modbus
